
<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v5.3.0, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.3.0, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/oip-96x96.jpg" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Candi Brahu</title>
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/animatecss/animate.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
  
</head>
<body>
  
  <section class="menu menu2 cid-sycH7ZVdyF" once="menu" id="menu2-12">
    
    <nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
        <div class="container-fluid">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="https://mobiri.se">
                        <img src="assets/images/oip-96x96.jpg" alt="Mobirise" style="height: 3rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-black text-primary display-4" href="index.html">Trowulan Tour</a></span>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item dropdown"><a class="nav-link link dropdown-toggle text-black display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="true">Tourist Attraction</a><div class="dropdown-menu"><a class="dropdown-item text-black text-primary display-4" href="page7.html">Candi Wringin Lawang</a><a class="text-black dropdown-item text-primary display-4" href="page5.html" aria-expanded="false">Candi Tikus</a><a class="text-black dropdown-item text-primary display-4" href="page2.html" aria-expanded="false">Candi Bajang Ratu</a><a class="text-black dropdown-item text-primary display-4" href="page4.html" aria-expanded="false">Museum Trowulan</a><a class="text-black dropdown-item text-primary display-4" href="page6.html" aria-expanded="false">Candi Brahu</a><a class="text-black dropdown-item text-primary display-4" href="page3.html" aria-expanded="false">Maha Vihara Majapahit</a></div></li><li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="index.html#features1-6">Features</a>
                    </li><li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="page11.html">
                            News</a></li></ul>
                
                <div class="navbar-buttons mbr-section-btn"><a class="btn btn-warning display-4" href="page12.html">Tours Package</a></div>
            </div>
        </div>
    </nav>
</section>

<section class="image1 cid-syeyk4VOnU" id="image1-14">
    

    

    <div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-lg-6">
                <div class="image-wrapper">
                    <img src="assets/images/candi-brahu-950x580.jpg" alt="Mobirise">
                    <p class="mbr-description mbr-fonts-style pt-2 align-center display-4">
                    Image Brahu Temple </p>
                </div>
            </div>
            <div class="col-12 col-lg">
                <div class="text-wrapper">
                    <h3 class="mbr-section-title mbr-fonts-style mb-3 display-2"><strong>Brahu Temple&nbsp;</strong></h3>
                    <p class="mbr-text mbr-fonts-style display-7">Brahu Temple is one of the temples located in the archaeological site of Trowulan, the former capital of Majapahit. To be precise, this temple is located in Jambu Mente Hamlet, Bejijong Village, Trowulan District, Mojokerto Regency, East Java.
<br>
<br>Brahu Temple was built in Buddhist style and culture. It is estimated that this temple was founded in the 15th century AD although there are still differences of opinion regarding this. Some say that this temple is much older than other temples around Trowulan.&nbsp;<br></p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="map1 cid-syeyklUduW" id="map1-15">
    
    
    <div class="container">
        <div class="mbr-section-head mb-4">
            <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2">
                <strong>Map</strong>
            </h3>
            
        </div>
        <div class="google-map"><iframe frameborder="0" style="border:0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3955.292864167737!2d112.37215721458553!3d-7.543006076555327!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e786ce655555555%3A0xb1299504be8c8c76!2sCandi%20Brahu!5e0!3m2!1sid!2sid!4v1621753719681!5m2!1sid!2sid" allowfullscreen=""></iframe></div>
    </div>
</section>

<section class="map1 cid-syeykID5Bf" id="map1-16">
    
    
    <div class="container">
        <div class="mbr-section-head mb-4">
            <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2"><strong>Augmented Reality</strong></h3>
            
        </div>
        <div class="google-map"><iframe frameborder="0" style="border:0" src="https://www.vectary.com/viewer/v1/?model=dc58ee8d-4c5e-4d52-b524-57e328b5581b&amp;env=studio3&amp;turntable=2" allowfullscreen=""></iframe></div>
    </div>
</section>

<section class="footer4 cid-sycYnf2wiF" once="footers" id="footer4-13">

    
    
    <div class="container">
        <div class="row mbr-white">
            <div class="col-6 col-lg-3">
                <div class="media-wrap col-md-8 col-12">
                    <a href="https://mobiri.se/">
                        <img src="assets/images/oip-128x128.png" alt="Mobirise">
                    </a>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-2">Trowulan Tour</h5>
                <p class="mbr-text mbr-fonts-style mb-4 display-4">Ojo lali mampir lur!</p>
                
                
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7"><strong>News</strong></h5>
                <ul class="list mbr-fonts-style display-4">
                    <li class="mbr-text item-wrap"><a href="page9.html" class="text-primary" style="font-size: 1.1rem; background-color: rgb(35, 35, 35);">About us</a><br></li><li class="mbr-text item-wrap"><a href="page10.html" class="text-primary">Get In Touch</a></li><li class="mbr-text item-wrap"><a href="page11.html" class="text-primary">News</a></li>
                </ul>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7"><strong>Categories</strong></h5>
                <ul class="list mbr-fonts-style display-4">
                    <li class="mbr-text item-wrap"><a href="index.html#features1-6" class="text-primary">Maps</a></li>
                    <li class="mbr-text item-wrap"><a href="index.html#features1-6" class="text-primary">Augmented Reality</a></li>
                    <li class="mbr-text item-wrap"><span style="font-size: 1.1rem;"><a href="index.html#features1-6" class="text-primary">360 Video</a></span><br></li>
                </ul>
            </div>
            
        </div>
    </div>
</section><section style="background-color: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif; color:#aaa; font-size:12px; padding: 0; align-items: center; display: flex;"><a href="https://mobirise.site/c" style="flex: 1 1; height: 3rem; padding-left: 1rem;"></a><p style="flex: 0 0 auto; margin:0; padding-right:1rem;">Designed with Mobirise - <a href="https://mobirise.site/l" style="color:#aaa;">More info</a></p></section><script src="assets/web/assets/jquery/jquery.min.js"></script>  <script src="assets/popper/popper.min.js"></script>  <script src="assets/tether/tether.min.js"></script>  <script src="assets/bootstrap/js/bootstrap.min.js"></script>  <script src="assets/smoothscroll/smooth-scroll.js"></script>  <script src="assets/viewportchecker/jquery.viewportchecker.js"></script>  <script src="assets/dropdown/js/nav-dropdown.js"></script>  <script src="assets/dropdown/js/navbar-dropdown.js"></script>  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>  <script src="assets/theme/js/script.js"></script>  
  
  
 <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a></div>
    <input name="animation" type="hidden">
  </body>
</html>