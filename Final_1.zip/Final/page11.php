
<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v5.3.0, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.3.0, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/oip-96x96.jpg" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>News</title>
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/animatecss/animate.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
  
</head>
<body>
  
  <section class="menu menu2 cid-sycH7ZVdyF" once="menu" id="menu2-1o">
    
    <nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
        <div class="container-fluid">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="https://mobiri.se">
                        <img src="assets/images/oip-96x96.jpg" alt="Mobirise" style="height: 3rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-black text-primary display-4" href="index.html">Trowulan Tour</a></span>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item dropdown"><a class="nav-link link dropdown-toggle text-black display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="true">Tourist Attraction</a><div class="dropdown-menu"><a class="dropdown-item text-black text-primary display-4" href="page7.html">Candi Wringin Lawang</a><a class="text-black dropdown-item text-primary display-4" href="page5.html" aria-expanded="false">Candi Tikus</a><a class="text-black dropdown-item text-primary display-4" href="page2.html" aria-expanded="false">Candi Bajang Ratu</a><a class="text-black dropdown-item text-primary display-4" href="page4.html" aria-expanded="false">Museum Trowulan</a><a class="text-black dropdown-item text-primary display-4" href="page6.html" aria-expanded="false">Candi Brahu</a><a class="text-black dropdown-item text-primary display-4" href="page3.html" aria-expanded="false">Maha Vihara Majapahit</a></div></li><li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="index.html#features1-6">Features</a>
                    </li><li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="page11.html">
                            News</a></li></ul>
                
                <div class="navbar-buttons mbr-section-btn"><a class="btn btn-warning display-4" href="page12.html">Tours Package</a></div>
            </div>
        </div>
    </nav>
</section>

<section class="content1 cid-sylKNw65z0" id="content1-1q">
    
    
    <div class="container">
        <div class="mbr-section-head">
            <h4 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2"><strong>Last News and Articles</strong></h4>
            <h5 class="mbr-section-subtitle mbr-fonts-style align-center mb-0 mt-2 display-5">Read the latest news about Trowulan</h5>
        </div>
        <div class="row mt-4">
            <div class="item features-image сol-12 col-md-6 col-lg-6">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="assets/images/screenshot-2021-05-25-indonesia-go-id-trowulan-adalah-ibu-kota-majapahit-1056x596.png" alt="" title="">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-2"><strong>Trowulan is the capital of Majapahit?&nbsp;</strong></h5>
                        <h6 class="item-subtitle mbr-fonts-style mt-1 display-7"><strong>Admin Indonesia.go.id</strong><em> 11-11-2019</em></h6>
                        <p class="mbr-text mbr-fonts-style mt-3 display-7">As has been reviewed in the article Mystery of the Location of the Majapahit Kedaton, that the popularity of the archaeological area of the Trowulan Site Situs&nbsp;<a href="https://indonesia.go.id/ragam/budaya/sosial/trowulan-adalah-ibu-kota-majapahit" class="text-primary" target="_blank">Read more..</a></p>
                    </div>
                    
                </div>
            </div>
            <div class="item features-image сol-12 col-md-6 col-lg-6">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="assets/images/092167500-1565164733-istock-933379748-1076x605.jpg" alt="" title="">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-2"><strong>Trowulan, an Educational and Entertaining Historical Site of Mojokerto&nbsp;</strong></h5>
                        <h6 class="item-subtitle mbr-fonts-style mt-1 display-7"><strong>Agustina Melani</strong><em> 03-09-2019</em></h6>
                        <p class="mbr-text mbr-fonts-style mt-3 display-7">Mojokerto, East Java has a priceless cultural heritage, one of which is the remains of the Majapahit Kingdom located in Trowulan Village..&nbsp;<a href="https://surabaya.liputan6.com/read/4053045/trowulan-situs-sejarah-mojokerto-yang-edukatif-dan-menghibur" class="text-primary" target="_blank">Read more..</a><br></p>
                    </div>
                    
                </div>
            </div>


        </div>
    </div>
</section>

<section class="footer4 cid-sycYnf2wiF" once="footers" id="footer4-1p">

    
    
    <div class="container">
        <div class="row mbr-white">
            <div class="col-6 col-lg-3">
                <div class="media-wrap col-md-8 col-12">
                    <a href="https://mobiri.se/">
                        <img src="assets/images/oip-128x128.png" alt="Mobirise">
                    </a>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-2">Trowulan Tour</h5>
                <p class="mbr-text mbr-fonts-style mb-4 display-4">Ojo lali mampir lur!</p>
                
                
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7"><strong>News</strong></h5>
                <ul class="list mbr-fonts-style display-4">
                    <li class="mbr-text item-wrap"><a href="page9.html" class="text-primary" style="font-size: 1.1rem; background-color: rgb(35, 35, 35);">About us</a><br></li><li class="mbr-text item-wrap"><a href="page10.html" class="text-primary">Get In Touch</a></li><li class="mbr-text item-wrap"><a href="page11.html" class="text-primary">News</a></li>
                </ul>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7"><strong>Categories</strong></h5>
                <ul class="list mbr-fonts-style display-4">
                    <li class="mbr-text item-wrap"><a href="index.html#features1-6" class="text-primary">Maps</a></li>
                    <li class="mbr-text item-wrap"><a href="index.html#features1-6" class="text-primary">Augmented Reality</a></li>
                    <li class="mbr-text item-wrap"><span style="font-size: 1.1rem;"><a href="index.html#features1-6" class="text-primary">360 Video</a></span><br></li>
                </ul>
            </div>
            
        </div>
    </div>
</section><section style="background-color: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif; color:#aaa; font-size:12px; padding: 0; align-items: center; display: flex;"><a href="https://mobirise.site/r" style="flex: 1 1; height: 3rem; padding-left: 1rem;"></a><p style="flex: 0 0 auto; margin:0; padding-right:1rem;">Make your own site with <a href="https://mobirise.site/z" style="color:#aaa;">Mobirise</a></p></section><script src="assets/web/assets/jquery/jquery.min.js"></script>  <script src="assets/popper/popper.min.js"></script>  <script src="assets/tether/tether.min.js"></script>  <script src="assets/bootstrap/js/bootstrap.min.js"></script>  <script src="assets/smoothscroll/smooth-scroll.js"></script>  <script src="assets/viewportchecker/jquery.viewportchecker.js"></script>  <script src="assets/dropdown/js/nav-dropdown.js"></script>  <script src="assets/dropdown/js/navbar-dropdown.js"></script>  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>  <script src="assets/theme/js/script.js"></script>  
  
  
 <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a></div>
    <input name="animation" type="hidden">
  </body>
</html>