
<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v5.3.0, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.3.0, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/oip-96x96.jpg" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Tours Package</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons2/mobirise2.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/animatecss/animate.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
  
</head>
<body>
  
  <section class="menu menu2 cid-sycH7ZVdyF" once="menu" id="menu2-1r">
    
    <nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
        <div class="container-fluid">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="https://mobiri.se">
                        <img src="assets/images/oip-96x96.jpg" alt="Mobirise" style="height: 3rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-black text-primary display-4" href="index.html">Trowulan Tour</a></span>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item dropdown"><a class="nav-link link dropdown-toggle text-black display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="true">Tourist Attraction</a><div class="dropdown-menu"><a class="dropdown-item text-black text-primary display-4" href="page7.html">Candi Wringin Lawang</a><a class="text-black dropdown-item text-primary display-4" href="page5.html" aria-expanded="false">Candi Tikus</a><a class="text-black dropdown-item text-primary display-4" href="page2.html" aria-expanded="false">Candi Bajang Ratu</a><a class="text-black dropdown-item text-primary display-4" href="page4.html" aria-expanded="false">Museum Trowulan</a><a class="text-black dropdown-item text-primary display-4" href="page6.html" aria-expanded="false">Candi Brahu</a><a class="text-black dropdown-item text-primary display-4" href="page3.html" aria-expanded="false">Maha Vihara Majapahit</a></div></li><li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="index.html#features1-6">Features</a>
                    </li><li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="page11.html">
                            News</a></li></ul>
                
                <div class="navbar-buttons mbr-section-btn"><a class="btn btn-warning display-4" href="page12.html">Tours Package</a></div>
            </div>
        </div>
    </nav>
</section>

<section class="header3 cid-szI6tY59Dm mbr-fullscreen mbr-parallax-background" id="header3-1z">

    

    <div class="mbr-overlay" style="opacity: 0.2; background-color: rgb(255, 255, 255);"></div>

    <div class="align-center container">
        <div class="row justify-content-end">
            <div class="col-12 col-lg-6">
                <h1 class="mbr-section-title mbr-fonts-style mb-3 display-1"><strong>Ready To Explore More Place With Us?</strong></h1>
                
                <p class="mbr-text mbr-fonts-style display-7">Scroll down to find best price.</p>
                
            </div>
        </div>
    </div>
</section>

<section class="header15 cid-syoKtw9EeT" id="header15-1t">
    

    

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-md">
                <div class="text-wrapper">
                    <h2 class="mbr-section-title mb-3 mbr-fonts-style display-2"><strong>Introduction Video</strong></h2>
                    <p class="mbr-text mb-3 mbr-fonts-style display-7">
                        Tracing traces of history, especially the history of the Hindu-Buddhist kingdom in the archipelago, becomes a very interesting and challenging thing. One of them is reconstructing the location of the capital city of the Majapahit kingdom. The remains of the Majapahit kingdom's actions that occurred more than hundreds of years ago, as well as relics of the Majapahit power center can be seen at the Trowulan site and the Majapahit museum. 
                    </p>
                    <div class="mbr-section-btn"><a class="btn btn-primary display-4" href="https://www.youtube.com/watch?v=shGjbpO_o1s">Learn more</a></div>
                </div>
            </div>
            <div class="mbr-figure col-12 col-md-7"><iframe class="mbr-embedded-video" src="https://www.youtube.com/embed/shGjbpO_o1s?rel=0&amp;amp;showinfo=0&amp;autoplay=1&amp;loop=0" width="1280" height="720" frameborder="0" allowfullscreen></iframe></div>
        </div>
    </div>
</section>

<section class="features23 cid-syoLqGg0S1" id="features24-1u">

    
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card-wrapper mb-4">
                    <div class="card-box align-center">
                        <h4 class="card-title mbr-fonts-style mb-4 display-2">
                            <strong>Steps</strong>
                        </h4>
                        
                        
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4">
                <div class="item first mbr-flex p-4">
                    <div class="icon-wrap w-100">
                        <div class="icon-box">
                            <span class="step-number mbr-fonts-style display-5">1</span>
                        </div>
                    </div>

                    <div class="text-box">
                        <h4 class="icon-title card-title mbr-black mbr-fonts-style display-7">
                            <strong>Choose Package</strong></h4>
                        
                    </div>
                </div>
                <!-- <span mbr-icon class="mbr-iconfont mobi-mbri-devices mobi-mbri"></span> -->
            </div>
            <div class="col-12 col-md-6 col-lg-4">
                <div class="item mbr-flex p-4">
                    <div class="icon-wrap w-100">
                        <div class="icon-box">
                            <span class="step-number mbr-fonts-style display-5">2</span>
                        </div>
                    </div>
                    <div class="text-box">
                        <h4 class="icon-title card-title mbr-black mbr-fonts-style display-7"><strong>Fill Form</strong></h4>
                        
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4">
                <div class="item mbr-flex p-4">
                    <div class="icon-wrap w-100">
                        <div class="icon-box">
                            <span class="step-number mbr-fonts-style display-5">3</span>
                        </div>
                    </div>
                    <div class="text-box">
                        <h4 class="icon-title card-title mbr-black mbr-fonts-style display-7"><strong>Confirm and Payment</strong></h4>
                        
                    </div>
                </div>
            </div>
            
            
            
            
            
        </div>
    </div>
</section>

<section class="pricing2 cid-syoLKKqLE4" id="pricing2-1v">
    

    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-md-6 align-center col-lg-4">
                <div class="plan">
                    <div class="plan-header">
                        <h6 class="plan-title mbr-fonts-style mb-3 display-5"><strong>One person package
</strong></h6>
                        <div class="plan-price">
                            <p class="price mbr-fonts-style m-0 display-2"><strong>IDR 300K</strong></p>
                            <p class="price-term mbr-fonts-style mb-3 display-7"></p>
                        </div>
                    </div>
                    <div class="plan-body">
                        <div class="plan-list mb-4">
                            <ul class="list-group mbr-fonts-style list-group-flush display-7">
                                <li class="list-group-item">Tour guide and Driver</li><li class="list-group-item">Include food and drink</li><li class="list-group-item">Accomodation for one night</li>
                            </ul>
                        </div>
                        <div class="mbr-section-btn text-center"><a href="page13.html" class="btn btn-primary display-4">Get started</a></div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 align-center col-lg-4">
                <div class="plan">
                    <div class="plan-header">
                        <h6 class="plan-title mbr-fonts-style mb-3 display-5"><strong>Minibus package</strong></h6>
                        <div class="plan-price">
                            <p class="price mbr-fonts-style m-0 display-2"><strong>IDR 3M</strong></p>
                            <p class="price-term mbr-fonts-style mb-3 display-7"></p>
                        </div>
                    </div>
                    <div class="plan-body">
                        <div class="plan-list mb-4">
                            <ul class="list-group mbr-fonts-style list-group-flush display-7">
                                <li class="list-group-item">Up to 13 person</li><li class="list-group-item">Include food and drink</li><li class="list-group-item">Tour guide and Driver</li><li class="list-group-item">Accomodation for one night</li>
                            </ul>
                        </div>
                        <div class="mbr-section-btn text-center"><a href="page13.html" class="btn btn-primary display-4">Get started</a></div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 align-center col-lg-4">
                <div class="plan">
                    <div class="plan-header">
                        <h6 class="plan-title mbr-fonts-style mb-3 display-5"><strong>Bus package</strong></h6>
                        <div class="plan-price">
                            <p class="price mbr-fonts-style m-0 display-2"><strong>IDR 13M</strong></p>
                            <p class="price-term mbr-fonts-style mb-3 display-7"></p>
                        </div>
                    </div>
                    <div class="plan-body">
                        <div class="plan-list mb-4">
                            <ul class="list-group mbr-fonts-style list-group-flush display-7">
                                <li class="list-group-item">Up to 50 person</li><li class="list-group-item">Include food and drink</li><li class="list-group-item">Tour Guide and Driver</li><li class="list-group-item">Accomodation for one night</li>
                            </ul>
                        </div>
                        <div class="mbr-section-btn text-center"><a href="page13.html" class="btn btn-primary display-4">Get started</a></div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>

<section class="features1 cid-syoMkZ4I7B" id="features1-1x">
    

    
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2">
                    <strong>Features</strong>
                </h3>
                
            </div>
        </div>
        <div class="row">
            <div class="card col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-box align-center">
                        <div class="iconfont-wrapper">
                            <span class="mbr-iconfont mobi-mbri-hot-cup mobi-mbri"></span>
                        </div>
                        <h5 class="card-title mbr-fonts-style display-7"><strong>Drinks, Food and Accommodation</strong></h5>
                        
                    </div>
                </div>
            </div>
            <div class="card col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-box align-center">
                        <div class="iconfont-wrapper">
                            <span class="mbr-iconfont mobi-mbri-file mobi-mbri"></span>
                        </div>
                        <h5 class="card-title mbr-fonts-style display-7"><strong>Tour Ticket</strong></h5>
                        
                    </div>
                </div>
            </div>
            <div class="card col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-box align-center">
                        <div class="iconfont-wrapper">
                            <span class="mbr-iconfont mobi-mbri-rocket mobi-mbri"></span>
                        </div>
                        <h5 class="card-title mbr-fonts-style display-7"><strong>Transportation including pickup and drop off</strong></h5>
                        
                    </div>
                </div>
            </div>
            <div class="card col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-box align-center">
                        <div class="iconfont-wrapper">
                            <span class="mbr-iconfont mobi-mbri-smile-face mobi-mbri"></span>
                        </div>
                        <h5 class="card-title mbr-fonts-style display-7"><strong>Professional Driver and Tour Guide</strong></h5>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="social1 cid-syoM5432YO" id="share1-1w">
    
    
    

    <div class="container">
        <div class="media-container-row">
            <div class="col-12">
                <h3 class="mbr-section-title mb-3 align-center mbr-fonts-style display-2">
                    <strong>Share this Page!</strong>
                </h3>
                <div>
                    <div class="mbr-social-likes align-center">
                        <span class="btn btn-social socicon-bg-facebook facebook m-2">
                            <i class="socicon socicon-facebook"></i>
                        </span>
                        <span class="btn btn-social twitter socicon-bg-twitter m-2">
                            <i class="socicon socicon-twitter"></i>
                        </span>
                        <span class="btn btn-social vkontakte socicon-bg-vkontakte m-2">
                            <i class="socicon socicon-vkontakte"></i>
                        </span>
                        <span class="btn btn-social odnoklassniki socicon-bg-odnoklassniki m-2">
                            <i class="socicon socicon-odnoklassniki"></i>
                        </span>
                        <span class="btn btn-social pinterest socicon-bg-pinterest m-2">
                            <i class="socicon socicon-pinterest"></i>
                        </span>
                        <span class="btn btn-social mailru socicon-bg-mail m-2">
                            <i class="socicon socicon-mail"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="footer4 cid-sycYnf2wiF" once="footers" id="footer4-1s">

    
    
    <div class="container">
        <div class="row mbr-white">
            <div class="col-6 col-lg-3">
                <div class="media-wrap col-md-8 col-12">
                    <a href="https://mobiri.se/">
                        <img src="assets/images/oip-128x128.png" alt="Mobirise">
                    </a>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-2">Trowulan Tour</h5>
                <p class="mbr-text mbr-fonts-style mb-4 display-4">Ojo lali mampir lur!</p>
                
                
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7"><strong>News</strong></h5>
                <ul class="list mbr-fonts-style display-4">
                    <li class="mbr-text item-wrap"><a href="page9.html" class="text-primary" style="font-size: 1.1rem; background-color: rgb(35, 35, 35);">About us</a><br></li><li class="mbr-text item-wrap"><a href="page10.html" class="text-primary">Get In Touch</a></li><li class="mbr-text item-wrap"><a href="page11.html" class="text-primary">News</a></li>
                </ul>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7"><strong>Categories</strong></h5>
                <ul class="list mbr-fonts-style display-4">
                    <li class="mbr-text item-wrap"><a href="index.html#features1-6" class="text-primary">Maps</a></li>
                    <li class="mbr-text item-wrap"><a href="index.html#features1-6" class="text-primary">Augmented Reality</a></li>
                    <li class="mbr-text item-wrap"><span style="font-size: 1.1rem;"><a href="index.html#features1-6" class="text-primary">360 Video</a></span><br></li>
                </ul>
            </div>
            
        </div>
    </div>
</section><section style="background-color: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif; color:#aaa; font-size:12px; padding: 0; align-items: center; display: flex;"><a href="https://mobirise.site/q" style="flex: 1 1; height: 3rem; padding-left: 1rem;"></a><p style="flex: 0 0 auto; margin:0; padding-right:1rem;"><a href="https://mobirise.site/i" style="color:#aaa;">Built with Mobirise</a> web creator</p></section><script src="assets/web/assets/jquery/jquery.min.js"></script>  <script src="assets/popper/popper.min.js"></script>  <script src="assets/tether/tether.min.js"></script>  <script src="assets/bootstrap/js/bootstrap.min.js"></script>  <script src="assets/smoothscroll/smooth-scroll.js"></script>  <script src="assets/viewportchecker/jquery.viewportchecker.js"></script>  <script src="assets/dropdown/js/nav-dropdown.js"></script>  <script src="assets/dropdown/js/navbar-dropdown.js"></script>  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>  <script src="assets/parallax/jarallax.min.js"></script>  <script src="assets/sociallikes/social-likes.js"></script>  <script src="assets/theme/js/script.js"></script>  
  
  
 <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a></div>
    <input name="animation" type="hidden">
  </body>
</html>