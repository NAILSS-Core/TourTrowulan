
<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v5.3.0, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.3.0, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/oip-96x96.jpg" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Home</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons2/mobirise2.css">
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons-bold/mobirise-icons-bold.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/animatecss/animate.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
  
</head>
<body>
  
  <section class="menu menu2 cid-sycH7ZVdyF" once="menu" id="menu2-3">
    
    <nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
        <div class="container-fluid">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="https://mobiri.se">
                        <img src="assets/images/oip-96x96.jpg" alt="Mobirise" style="height: 3rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-black text-primary display-4" href="index.html">Trowulan Tour</a></span>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item dropdown"><a class="nav-link link dropdown-toggle text-black display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="true">Tourist Attraction</a><div class="dropdown-menu"><a class="dropdown-item text-black text-primary display-4" href="page7.html">Candi Wringin Lawang</a><a class="text-black dropdown-item text-primary display-4" href="page5.html" aria-expanded="false">Candi Tikus</a><a class="text-black dropdown-item text-primary display-4" href="page2.html" aria-expanded="false">Candi Bajang Ratu</a><a class="text-black dropdown-item text-primary display-4" href="page4.html" aria-expanded="false">Museum Trowulan</a><a class="text-black dropdown-item text-primary display-4" href="page6.html" aria-expanded="false">Candi Brahu</a><a class="text-black dropdown-item text-primary display-4" href="page3.html" aria-expanded="false">Maha Vihara Majapahit</a></div></li><li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="index.html#features1-6">Features</a>
                    </li><li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="page11.html">
                            News</a></li></ul>
                
                <div class="navbar-buttons mbr-section-btn"><a class="btn btn-warning display-4" href="page12.html">Tours Package</a></div>
            </div>
        </div>
    </nav>
</section>

<section class="header13 cid-sycK17qUMr mbr-fullscreen mbr-parallax-background" id="header13-4">

    

    <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(255, 225, 97);"></div>

    <div class="align-center container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10">
                <h1 class="mbr-section-title mbr-fonts-style mb-3 display-1"><strong>Trowulan Tour</strong></h1>
                
                <p class="mbr-text mbr-fonts-style mb-3 display-7">Mojokerto Regency has many relics of the former glory of the Majapahit Kingdom.
<br>Even predicted as the center of the kingdom.&nbsp;</p>
                
                
            </div>
        </div>
    </div>
</section>

<section class="features15 cid-sycLiOMGvM" id="features16-5">

    

    
    <div class="container">
        <div class="content-wrapper">
            <div class="row align-items-center">
                <div class="col-12 col-lg">
                    <div class="text-wrapper">
                        <h6 class="card-title mbr-fonts-style display-2"><strong>Do you know what Trowulan is?&nbsp;</strong></h6>
                        <p class="mbr-text mbr-fonts-style mb-4 display-7">
                            Trowulan is a historical heritage site that includes several villages and sub-districts on the border of Mojokerto and Jombang regencies, in Trowulan we can find a lot of historical relics which allegedly came from the Majapahit kingdom and previous kingdoms. </p>
                        <div class="mbr-section-btn mt-3"><a class="btn btn-warning display-7" href="page8.html">Learn more</a></div>
                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="image-wrapper">
                        <img src="assets/images/-dsc7604-trowulan-720x482.jpg" alt="Mobirise">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="features1 cid-sycM1s8NPs mbr-parallax-background" id="features1-6">
    
<script src="https://apps.elfsight.com/p/platform.js" defer=""></script>
<div class="elfsight-app-302b8c85-0389-4379-8b45-544d6e8e9815"></div>
    <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(255, 225, 97);">
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-lg-9">
                <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2">
                    <strong>Features</strong>
                </h3>
                
            </div>
        </div>
        <div class="row">
            <div class="card col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-box align-center">
                        <div class="iconfont-wrapper">
                            <span class="mbr-iconfont mbrib-map-pin"></span>
                        </div>
                        <h5 class="card-title mbr-fonts-style display-7"><strong>MAPS</strong></h5>
                        <p class="card-text mbr-fonts-style display-7">Explore Trowulan Tourism with Maps makes it easy for you to find interesting places! </p>
                    </div>
                </div>
            </div>
            <div class="card col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-box align-center">
                        <div class="iconfont-wrapper">
                            <span class="mbr-iconfont socicon-yt-gaming socicon"></span>
                        </div>
                        <h5 class="card-title mbr-fonts-style display-7"><strong>AUGMENTED REALITY</strong></h5>
                        <p class="card-text mbr-fonts-style display-7">Use the Augmented Reality feature to make the new travel experience even more amazing! </p>
                    </div>
                </div>
            </div>
            <div class="card col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-box align-center">
                        <div class="iconfont-wrapper">
                            <span class="mbr-iconfont mbrib-play"></span>
                        </div>
                        <h5 class="card-title mbr-fonts-style display-7"><strong>360 CAMERA</strong></h5>
                        <p class="card-text mbr-fonts-style display-7">Search tourist attractions only with your electronic device. You don't have to come to a tourist spot! </p>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>

<section class="features3 cid-sycTzlhULk" id="features3-8">
    
    
    <div class="container">
        <div class="mbr-section-head">
            <h4 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2"><strong>Tourist Spot</strong></h4>
            
        </div>
        <div class="row mt-4">
            <div class="item features-image сol-12 col-md-6 col-lg-4">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="assets/images/gapura-wringin-lawang-696x464.jpeg" alt="">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-7"><strong>Wringin Lawang Temple&nbsp;</strong></h5>
                        
                        <p class="mbr-text mbr-fonts-style mt-3 display-7">Wringin Lawang Gate is a 14th century Majapahit heritage gate located in the District... </p>
                    </div>
                    <div class="mbr-section-btn item-footer mt-2"><a href="page7.html" class="btn item-btn btn-white display-7" target="_blank">Learn More
                            &gt;</a></div>
                </div>
            </div>
            <div class="item features-image сol-12 col-md-6 col-lg-4">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="assets/images/candi-tikus-696x462.jpg" alt="">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-7"><strong>Tikus Temple</strong></h5>
                        
                        <p class="mbr-text mbr-fonts-style mt-3 display-7">Touted as the Capital of the Majapahit Kingdom, Candi Tikus
<br>found in Dukuh Dinuk, Temon Village, Trowulan District...&nbsp;</p>
                    </div>
                    <div class="mbr-section-btn item-footer mt-2"><a href="page5.html" class="btn item-btn btn-white display-7" target="_blank">Learn More
                            &gt;</a></div>
                </div>
            </div>
            <div class="item features-image сol-12 col-md-6 col-lg-4">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="assets/images/candi-wringin-696x466.jpg" alt="">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-7"><strong>Bajang Ratu Temple</strong></h5>
                        
                        <p class="mbr-text mbr-fonts-style mt-3 display-7">Bajang Ratu Temple or often called the Bajang Ratu gate is a temple relic of the Majapahit kingdom... <br></p>
                    </div>
                    <div class="mbr-section-btn item-footer mt-2"><a href="page2.html" class="btn item-btn btn-white display-7" target="_blank">Learn More
                            &gt;</a></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="features3 cid-sycTCbl5QQ" id="features3-9">
    
    
    <div class="container">
        
        <div class="row mt-4">
            <div class="item features-image сol-12 col-md-6 col-lg-4">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="assets/images/museum-trowulan-650x488.jpg" alt="">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-7"><strong>Trowulan Museum&nbsp;</strong></h5>
                        
                        <p class="mbr-text mbr-fonts-style mt-3 display-7">Trowulan Museum is an archaeological museum located in Trowulan, Mojokerto, East Java, Indonesia...  </p>
                    </div>
                    <div class="mbr-section-btn item-footer mt-2"><a href="page4.html" class="btn item-btn btn-white display-7" target="_blank">Learn More
                            &gt;</a></div>
                </div>
            </div>
            <div class="item features-image сol-12 col-md-6 col-lg-4">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="assets/images/kemegahan-candi-brahu-di-tengah-hijaunya-rerumputan.-foto-gmap-fathoni-696x464.jpeg" alt="">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-7"><strong>Brahu Temple&nbsp;</strong></h5>
                        
                        <p class="mbr-text mbr-fonts-style mt-3 display-7">Brahu Temple is one of the temples located in
<br>Trowulan archaeological site area, the former capital of Majapahit...</p>
                    </div>
                    <div class="mbr-section-btn item-footer mt-2"><a href="page6.html" class="btn item-btn btn-white display-7" target="_blank">Learn More
                            &gt;</a></div>
                </div>
            </div>
            <div class="item features-image сol-12 col-md-6 col-lg-4">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="assets/images/mahavihara-majapahit-mojokerto-jawa-timur-1024x768.jpeg" alt="">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-7"><strong>Maha Vihara Majapahit</strong></h5>
                        
                        <p class="mbr-text mbr-fonts-style mt-3 display-7">Maha Vihara Majapahit is a monastery located in Bejijong Village, Trowulan District, Mojokerto Regency.  </p>
                    </div>
                    <div class="mbr-section-btn item-footer mt-2"><a href="page3.html" class="btn item-btn btn-white display-7" target="_blank">Learn More
                            &gt;</a></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="footer4 cid-sycYnf2wiF" once="footers" id="footer4-a">

    
    
    <div class="container">
        <div class="row mbr-white">
            <div class="col-6 col-lg-3">
                <div class="media-wrap col-md-8 col-12">
                    <a href="https://mobiri.se/">
                        <img src="assets/images/oip-128x128.png" alt="Mobirise">
                    </a>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-2">Trowulan Tour</h5>
                <p class="mbr-text mbr-fonts-style mb-4 display-4">Ojo lali mampir lur!</p>
                
                
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7"><strong>News</strong></h5>
                <ul class="list mbr-fonts-style display-4">
                    <li class="mbr-text item-wrap"><a href="page9.html" class="text-primary" style="font-size: 1.1rem; background-color: rgb(35, 35, 35);">About us</a><br></li><li class="mbr-text item-wrap"><a href="page10.html" class="text-primary">Get In Touch</a></li><li class="mbr-text item-wrap"><a href="page11.html" class="text-primary">News</a></li>
                </ul>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7"><strong>Categories</strong></h5>
                <ul class="list mbr-fonts-style display-4">
                    <li class="mbr-text item-wrap"><a href="index.html#features1-6" class="text-primary">Maps</a></li>
                    <li class="mbr-text item-wrap"><a href="index.html#features1-6" class="text-primary">Augmented Reality</a></li>
                    <li class="mbr-text item-wrap"><span style="font-size: 1.1rem;"><a href="index.html#features1-6" class="text-primary">360 Video</a></span><br></li>
                </ul>
            </div>
            
        </div>
    </div>
</section><section style="background-color: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif; color:#aaa; font-size:12px; padding: 0; align-items: center; display: flex;"><a href="https://mobirise.site/o" style="flex: 1 1; height: 3rem; padding-left: 1rem;"></a><p style="flex: 0 0 auto; margin:0; padding-right:1rem;">Website was <a href="https://mobirise.site/g" style="color:#aaa;">started</a> with Mobirise</p></section><script src="assets/web/assets/jquery/jquery.min.js"></script>  <script src="assets/popper/popper.min.js"></script>  <script src="assets/tether/tether.min.js"></script>  <script src="assets/bootstrap/js/bootstrap.min.js"></script>  <script src="assets/smoothscroll/smooth-scroll.js"></script>  <script src="assets/viewportchecker/jquery.viewportchecker.js"></script>  <script src="assets/dropdown/js/nav-dropdown.js"></script>  <script src="assets/dropdown/js/navbar-dropdown.js"></script>  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>  <script src="assets/parallax/jarallax.min.js"></script>  <script src="assets/theme/js/script.js"></script>  
  
  
 <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a></div>
    <input name="animation" type="hidden">
  </body>
</html>